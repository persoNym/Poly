/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p9;

import java.awt.*;
import java.awt.event.KeyEvent.*;

public class P9Model {
    
     static Color Color1 = null;//fill shape color
     static Color Color2 = null;//line color
     int[] polyX = new int[4];//array to hold points for polygon
     int[] polyY = new int[4];
     int[] lineX = new int[2];
     int[] lineY = new int[2];//array to hold points for line
     int count = 0;//keep counts of poly array
     int line = 0;//keep count of line array
     int xx = 0; //polygon points
     int yy= 0;
     int xxx =0;//line points
     int yyy =0;
}
